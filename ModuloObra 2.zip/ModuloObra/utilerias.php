<?php
function redireccionar($mensaje, $dir){
        echo '<div class="formulario-div" style="color:brown"> ';
        echo '<h1 style="text-align:center"> '. $mensaje .' </h1>';
        echo '<h4 style="text-align:center"> Redireccionando... </h4>';
        echo '</div>';
       header('refresh:3,url='. $dir);
    }

function redireccionarR($dir){
       header('refresh:0.01,url='. $dir);
}

?>