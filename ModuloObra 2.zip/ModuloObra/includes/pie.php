</main>

<!-- Inicio Pie de página -->
<footer>
    <div class="columnas-pie">
        <div class="contacto">
            <h4>Contacto</h4>
            <p>Teléfono: 311 322 4598</p>
            <p>correo: contacto@dulcevida.com</p>
        </div>
        <div class="redes">
            <h4>Síguenos</h4>
            <p>Facebook</p>
            <p>Instagram</p>
        </div>
        <div class="general">
            <p>Preguntas frecuentes</p>
            <p>Políticas del sitio</p>
            <p>Términos y condiciones</p>
        </div>
    </div>
    <p class="derechos">&copy;Todos los derechos reservados. Repostería Dulce Vida 2020</p>
</footer>
<!-- Fin Pie de página -->

</body>
</html>