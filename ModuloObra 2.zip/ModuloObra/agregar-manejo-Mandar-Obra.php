<?php
    include ('conexionBD.php');
    include('utilerias.php');
    $conexion = conectar();
    if (!$conexion){
        //redireccionar('ERROR DE CONEXION','index.php');
        //return;
    }
    
    
    
    $id = $_GET['t1'];
    
    
   $sql = "select * from presupuesto_obras where ID_PRESUPUESTO='$id';";
   $resultado = mysqli_query($conexion,$sql);
   
   while ($row = mysqli_fetch_array($resultado)) {  
       $IdPresupuesto =  $row['ID_PRESUPUESTO'];
       $t2 =  $row['NOMBRE_OBRA'];
       $t5 =  $row['NOMBRE_CLIENTE'];
       $t6 =  $row['TELEFONO_CLIENTE'];
       $t7 =  $row['UBICACION_CLIENTE'];
   }

   
   $sql = "select sum(IMPORTE_NUMERO) as total from catalogo_presupuesto where ID_PRESUPUESTO='$id';";
   $resultado = mysqli_query($conexion,$sql);

   while ($row = mysqli_fetch_array($resultado)) {  
       $t11 = $row['total'];
   }
   $t1="";
   $t3="";
   $t4="";
   $t8="";
   $t9="";
   $t10="";
   header('Location: obra.php?t1='.$t1.'&t2='.$t2.'&t3='.$t3.'&t4='.$t4.'&t5='.$t5.'&t6='.$t6.'&t7='.$t7.'&t8='.$t8.'&t9='.$t9.'&t10='.$t10.'&t11='.$t11.'&IdPresupuesto='.$IdPresupuesto);

   //ECHO $t1." ".$t2." ".$t3." ".$t4." ".$t5." ".$t6;
        //redireccionar('Se ha agregado exitosamente','Presupuesto.php');
    


?>