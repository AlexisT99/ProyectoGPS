<?php
    if(session_status() == PHP_SESSION_NONE){
        session_start();
    }

    $conexion = new mysqli("localhost", "root", "", "dynasoft");
    $sql="SELECT id_obra, nombre from registro_obras";
    $result = $conexion->query($sql);
    if ($result->num_rows > 0)
    {
        $combobit="";
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) 
        {
            $combobit .="<option value='".$row['id_obra']."'>".$row['nombre']."</option>";  
        }
    }
    else
    {
        echo "No hubo resultados";
    }   

    $sql2="SELECT idtrabajador, nombretrab from trabajadores";
    $result2 = $conexion->query($sql2);
    if ($result2->num_rows > 0)
    {
        $combobit2="";
        while ($row = $result2->fetch_array(MYSQLI_ASSOC)) 
        {
            $combobit2 .="<option value='".$row['idtrabajador']."'>".$row['nombretrab']."</option>";  
        }
    }
    else
    {
        echo "No hubo resultados";
    }  
    
    $sql3="SELECT codigo_equipo, descripcion_equipo from equipo";
    $result3 = $conexion->query($sql3);
    if ($result3->num_rows > 0)
    {
        $combobit3="";
        while ($row = $result3->fetch_array(MYSQLI_ASSOC)) 
        {
            $combobit3 .="<option value='".$row['codigo_equipo']."'>".$row['descripcion_equipo']."</option>";  
        }
    }
    else
    {
        echo "No hubo resultados";
    } 
    
    $sql4="SELECT id_material, nombre_material from material";
    $result4 = $conexion->query($sql4);
    if ($result4->num_rows > 0)
    {
        $combobit4="";
        while ($row = $result4->fetch_array(MYSQLI_ASSOC)) 
        {
            $combobit4 .="<option value='".$row['id_material']."'>".$row['nombre_material']."</option>";  
        }
    }
    else
    {
        echo "No hubo resultados";
    } 

    $id = (!empty ($_GET['t1']) ) ? $_GET['t1'] : NULL; 
    if ( $id ) {            
        $op1=$op2=$op3=$op4=$op5=$op6=$op7=$op8="";
        $t1= $_GET['t1'];
        $sql5="SELECT nombre from registro_obras where id_obra = '".$_GET['t2']."'";
        $query5 = mysqli_query($conexion,$sql5);
        $result5 = mysqli_fetch_assoc($query5);
        $n5 = $result5['nombre'];
        $t2 ="<option value='".$_GET['t2']."'>".$n5."</option>";
        $sql6="SELECT nombretrab from trabajadores where idtrabajador = '".$_GET['t3']."'";
        $query6 = mysqli_query($conexion,$sql6);
        $result6 = mysqli_fetch_assoc($query6);
        $n6 = $result6['nombretrab'];
        $t3 ="<option value='".$_GET['t3']."'>".$n6."</option>";  
        $sql7="SELECT descripcion_equipo from equipo where codigo_equipo = '".$_GET['t4']."'";
        $query7 = mysqli_query($conexion,$sql7);
        $result7 = mysqli_fetch_assoc($query7);
        $n7 = $result7['descripcion_equipo'];
        $t4 ="<option value='".$_GET['t4']."'>".$n7."</option>";  
        $t5= $_GET['t5'];
        $sql8="SELECT nombre_material from material where id_material = '".$_GET['t5']."'";
        $query8 = mysqli_query($conexion,$sql8);
        $result8 = mysqli_fetch_assoc($query8);
        $n8 = $result8['nombre_material'];
        $t5 ="<option value='".$_GET['t5']."'>".$n8."</option>";  
        $t6= $_GET['t6'];
        $t7= $_GET['t7'];
        $t8 = $_GET['t8'];
        $t9 = $_GET['t9'];
    } else {
        $t1="";
        $t2=$combobit;
        $t3=$combobit2;
        $t4=$combobit3;
        $t5=$combobit4;
        $t6="";
        $t7="";
        $t8="PENDIENTE";
        $t9="";
       
        $op1=$op2=$op3=$op4=$op5=$op6=$op7=$op8="";
    }

    
    
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Agregar_incidente</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <!-- Start: Sidebar Menu -->
    <div id="wrapper">
        <div id="sidebar-wrapper" style="background: rgb(19,46,77);">
        <ul class="sidebar-nav">
                <li class="sidebar-brand"> <a href="../index.php?action=inicio"
                        style="font-weight: bold;color: rgb(255,255,255);font-size: 24px;">DynaSoft</a></li>
                        <li class="sidebar-brand";> <a href="obra-index.php"
                        style="font-weight: bold;color: rgb(255,255,255);font-size: 20px;">Modulo Obras</a>
                        <li> <a href="Crear_Presupuesto.php" style="color: rgb(255,255,255);font-size: 19px;">Presupuesto</a></li>
                <li> <a href="Obra.php" style="color: rgb(255,255,255);font-size: 19px;">Obra</a></li>
                <li> <a href="Incidentes.php" style="color: rgb(255,255,255);font-size: 19px;">Incidentes</a><a href="avisos.php"
                        style="color: rgb(255,255,255);font-size: 16px;margin: 0px;padding: 5px;padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 15px;">Avisos</a></li>
                
                <li> <a href="muestreo_Concreto_Principal.php" style="color: rgb(255,255,255);font-size: 19px;">Informe de muestreo</a></li>
                <li> <a href="resistencias.php" style="color: rgb(255,255,255);font-size: 19px;">Informe de resistencias&nbsp;</a></li>
                <li> <a href="ingresos.php" style="color: rgb(255,255,255);font-size: 19px;">Ingresos</a></li>
                <li> </li>
            </ul>
        </div>
        <div class="page-content-wrapper">
            <div class="container-fluid" style="background: #124177;"><a class="btn btn-link" role="button"
                    id="menu-toggle" href="#menu-toggle"><i class="fa fa-bars" style="color: var(--white);"></i></a>
                <div class="row">
                    <div class="col-md-12">
                        <div>
                            <h1 style="color: rgb(255,255,255);">Modulo&nbsp;<small>Incidentes</small></h1>
                        </div>
                    </div>
                </div>
            </div>

            <div>

            <form action="agregar-manejo_incidentes.php" class="formulario" method="post"  >
                <div class="jumbotron" style="background: rgba(233,236,239,0);padding-top: 34px;padding-bottom: 0px;">
                    <h1 style="padding-bottom: 25px;">Agregar Incidentes</h1>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 25px;">Id Incidente:</label><input
                            id="Inc_I" name="inc_I" type="text" style="width: 550px;" value='<?php echo $t1; ?>'></p>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 50px;">Id Obra:</label>
                    <select name="obr_I" style="width: 550px;">
                                <?php echo $t2; ?>
                    </select>
                    </p>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 10px;">Id Trabajador:</label>
                    <select name="tra_I" style="width: 550px;">
                                <?php echo $t3; ?>
                            </select>
                    </p>

                    <p style="padding-bottom: 0px;"><label style="padding-right: 35px;">Id Equipo:</label>
                    <select name="equ_I" style="width: 550px;">
                                <?php echo $t4; ?>
                            </select></p>

                    <p style="padding-bottom: 0px;"><label style="padding-right: 28px;">Id Material:</label>
                    <select name="mat_I" style="width: 550px;">
                                <?php echo $t5; ?>
                            </select>
                    </p>
                    <p style="padding-bottom: 0px;"><label style="padding-right:25px;">Descripción:</label><input
                            id="Des_I" name="des_I" type="text" style="width: 550px;height: 70px;" value='<?php echo $t6; ?>'></p>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 65px;">Fecha:</label><input type="date" min='<?php echo date('Y-m-d'); ?>'
                            id="Fec_I" name="fec_I" style="width: 150px;" value='<?php echo $t7; ?>'></p>
                    

                    <hr>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 45px;">Peticion:</label>
                    <input type="text" disabled="disabled" id="Peticion" name="Peticion" style="width: 550px;" value='<?php echo $t8; ?>'></p>

                    <hr>
                    <p style="padding-bottom: 0px;"><label style="padding-right: 75px;">Foto:</label><input type="file"
                            id="Fot_I" name="fot_I"accept="image/*" style="width: 300px;height: 40px;" value='<?php echo $t9; ?>'></p>
                            
                    <p>
                    
                            <input type="submit" value="Guardar" name="guardar" class="boton" style="font-weight: bold
                            ;background: rgb(10,126,29);margin: 13px;width: 91px; height:40px; border:1px solid rgb(0,123,255); color:white; border-radius:5px">
                            
                            <input type="submit" value="Actualizar" name="actualizar" class="boton" style="font-weight: bold
                            ;background: rgb(10,126,29);margin: 13px;width: 91px; height:40px; border:1px solid rgb(0,123,255); color:white; border-radius:5px">
                            
                            <input type="submit" value="Borrar" name="borrar" class="boton" style="font-weight: bold
                            ;background: rgb(146,0,0);margin: 13px;width: 91px; height:40px; border:1px solid rgb(0,123,255); color:white; border-radius:5px">

                            <input type="submit" value="Limpiar" name="limpiar" class="boton" style="font-weight: bold
                            ;background: rgb(146,0,0);margin: 13px;width: 91px; height:40px; border:1px solid rgb(0,123,255); color:white; border-radius:5px">

                    <!--<a class="btn btn-primary" role="button"
                            style="font-weight: bold;background: rgb(10,126,29);margin: 13px;width: 91px;">Agregar</a><a
                            class="btn btn-primary" role="button"
                            style="font-weight: bold;background: rgb(10,126,29);margin: 13px;width: 100px;">Actualizar</a><a
                            class="btn btn-primary" role="button"
                            style="font-weight: bold;background: rgb(143,0,0);margin: 13px;width: 91px;">Borrar</a><a
                            class="btn btn-primary" role="button"
                            style="font-weight: bold;background: rgb(143,0,0);margin: 13px;width: 91px;">Limpiar</a></p>-->

                </div><!-- Start: Pretty Footer -->
                </form>
                

                <div class="jumbotron" style="background: rgba(233,236,239,0);padding-top: 34px;padding-bottom: 0px;">
                <hr size="20px" color="black">
                <h1 style="padding-bottom: 25px;">Buscar Incidente</h1>
                <form action="Incidente_consulta.php" method="post" >
                        <!--<p style="padding-bottom: 0px;"><label style="padding-right: 30px;">Nombre Obra:</label><input
                                type="text" style="width: 550px;"></p>
                        <p style="padding-bottom: 0px;"><label style="padding-right: 53px;">Lider Obra:</label><input
                                type="text" style="width: 550px;"></p>
                        <p style="padding-bottom: 0px;"><label style="padding-right: 95px;">Area:</label><input type="text"
                                style="width: 550px;"></p>
                                -->
                        <p style="padding-bottom: 0px;"><label style="padding-right: 10px;">Id Obra:</label>
                        <select id ="numObra" name="numObra" style="width: 550px;">
                                <?php echo $combobit; ?>
                        </select>
                        </p>
                        <input type="submit" value="Buscar" id="Buscar" name="buscar" class="boton" style="font-weight: bold
                            ;background: rgb(10,126,29);margin: 13px;width: 91px; height:40px; border:1px solid rgb(0,123,255); color:white; border-radius:5px">
                        
                         

                    </form>  
                <footer>
                    <div class="row">
                        <div class="col-sm-6 col-md-4 footer-navigation">
                            <h3><a href="#">Company<span>logo </span></a></h3>
                            <p class="links"><a href="#">Home</a><strong> · </strong><a href="#">Blog</a><strong> ·
                                </strong><a href="#">Pricing</a><strong> · </strong><a href="#">About</a><strong> ·
                                </strong><a href="#">Faq</a><strong> · </strong><a href="#">Contact</a></p>
                            <p class="company-name">Company Name © 2015 </p>
                        </div>
                        <div class="col-sm-6 col-md-4 footer-contacts">
                            <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                                <p><span class="new-line-span">21 Revolution Street</span> Paris, France</p>
                            </div>
                            <div><i class="fa fa-phone footer-contacts-icon"></i>
                                <p class="footer-center-info email text-left"> +1 555 123456</p>
                            </div>
                            <div><i class="fa fa-envelope footer-contacts-icon"></i>
                                <p> <a href="#" target="_blank">support@company.com</a></p>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-4 footer-about">
                            <h4>About the company</h4>
                            <p> Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit,
                                eu auctor lacus vehicula sit amet. </p>
                            <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a
                                    href="#"><i class="fa fa-twitter"></i></a><a href="#"><i
                                        class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a>
                            </div>
                        </div>
                    </div>
                </footer><!-- End: Pretty Footer -->
            </div>
        </div>
    </div><!-- End: Sidebar Menu -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>