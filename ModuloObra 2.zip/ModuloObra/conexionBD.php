
<?php

    function conectar(){
        


        IF (!DEFINED('SERVIDOR')) DEFINE('SERVIDOR','localhost');
        IF (!DEFINED('USUARIO')) DEFINE('USUARIO','root');
        IF (!DEFINED('PASSWORD')) DEFINE('PASSWORD','');
        IF (!DEFINED('BD')) DEFINE('BD','dynasoft');
    
        $resultado = mysqli_connect(SERVIDOR,USUARIO,PASSWORD,BD);
        return $resultado;
}

?>