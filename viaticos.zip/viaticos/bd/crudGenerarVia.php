<?php
include_once '../bd/conexion.php';
include '../ChromePhp.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$IDVIATICO = (isset($_POST['id_viatico'])) ? $_POST['id_viatico'] : '';
$NOMBRETRAB = (isset($_POST['NOMBRETRAB'])) ? $_POST['NOMBRETRAB'] : '';
$IDTRABAJADOR = (isset($_POST['IDTRABAJADOR'])) ? $_POST['IDTRABAJADOR'] : '';
$FECHAASIG = (isset($_POST['FECHAASIG'])) ? $_POST['FECHAASIG'] : '';
$MONTO = (isset($_POST['MONTO'])) ? $_POST['MONTO'] : '';
$IDTIVIATICO = (isset($_POST['IDTIVIATICO'])) ? $_POST['IDTIVIATICO'] : '';
$MONTOVIAT  = (isset($_POST['MONTOVIAT'])) ? $_POST['MONTOVIAT'] : '';
$DESCVIAT  = (isset($_POST['DESCVIAT'])) ? $_POST['DESCVIAT'] : '';

$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';

switch($opcion){
    case 1:
        $consulta = "INSERT INTO viaticos (IDTRABAJADOR , FECHAASIG , MONTO ) VALUES('$IDTRABAJADOR', '$FECHAASIG',0);";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute(); 
        
        $consulta = "SELECT v.IDVIATICO, CONCAT(T.NOMBRETRAB,' ', T.APEPATTRAB, ' ', T.APEMATTRAB ) as 'NOMBRETRAB', T.IDTRABAJADOR ,v.FECHAASIG, v.MONTO from viaticos v inner join trabajadores T on T.IDTRABAJADOR = v.IDTRABAJADOR ";    
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);       
        break;    
        
        
  
        case 2:  
        $consulta = "INSERT INTO tipviat_Viaticos (IDVIATICO , IDTIVIATICO , MONTOVIAT , DESCVIAT , ESTADO  ) VALUES('$IDVIATICO', '$IDTIVIATICO','$MONTOVIAT', '$DESCVIAT', 'E');";	
        ChromePhp::log($IDVIATICO);
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "UPDATE `viaticos` SET `MONTO` = (MONTO+'$MONTOVIAT') WHERE `viaticos`.`IDVIATICO` = '$IDVIATICO';";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $consulta = "SELECT v.IDVIATICO, CONCAT(T.NOMBRETRAB,' ', T.APEPATTRAB, ' ', T.APEMATTRAB ) as 'NOMBRETRAB', T.IDTRABAJADOR ,v.FECHAASIG, v.MONTO from viaticos v inner join trabajadores T on T.IDTRABAJADOR = v.IDTRABAJADOR ";    
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();       
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break; 
    case 3:        
        $consulta = "DELETE FROM nomina WHERE IDVIATICO = '$IDVIATICO'";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break; 
    case 4:
        $consulta = "SELECT v.IDVIATICO, CONCAT(T.NOMBRETRAB,' ', T.APEPATTRAB, ' ', T.APEMATTRAB ) as 'NOMBRETRAB', T.IDTRABAJADOR ,v.FECHAASIG, v.MONTO from viaticos v inner join trabajadores T on T.IDTRABAJADOR = v.IDTRABAJADOR ";    
        //$consulta = "SELECT t.IDTRABAJADOR ,t.NOMBRETRABTRAB, t.IDTRABAJADORTRAB, t.FECHAASIGTRAB, p.NOMBRETRABPUESTO, t.MONTOTRAB, t.OBSPAGOTRAB , t.TIPOPERCEPCIONESTRAB ,t.CUENTABANCTRAB ,t.NOSEGUROTRAB from trabajadores t INNER JOIN puestos p on t.IDPUESTOS = p.IDPUESTOS";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
   
}


print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;

