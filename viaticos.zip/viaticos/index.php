<!DOCTYPE html>
<html lang="en">
    

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Generar Viaticos</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu-1.css">
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-v2-Modal--Full-with-Google-Map.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <!-- Cosas para la datatables -->

    <!-- imports para el modal -->
    <link rel="stylesheet" href="assetsModal/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assetsModal/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assetsModal/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assetsModal/fonts/material-icons.min.css">
    <link rel="stylesheet" href="assetsModal/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assetsModal/css/Contact-Form-v2-Modal--Full-with-Google-Map.css">
    <link rel="stylesheet" href="assetsModal/css/styles.css">
    <!-- Se acaban los imports para el modal  -->

     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
      
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="assets/datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="assets/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">    
      
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">  

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <!-- Cosas para la datatables -->
    
</head>

<body>
    <div id="wrapper">
        <div id="sidebar-wrapper" style="background: rgb(19,46,77);">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"> <a href="#" style="font-weight: bold;color: rgb(255,255,255);font-size: 24px;">DynaSoft</a></li>
                <li> <a href="#" style="color: rgb(255,255,255);font-size: 19px;">Trabajador</a></li>
                <li> <a href="#" style="color: rgb(255,255,255);font-size: 19px;">Puestos</a><a href="#" style="color: rgb(255,255,255);font-size: 16px;margin: 0px;padding: 5px;padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 15px;">Prueba</a><a href="#" style="color: rgb(255,255,255);font-size: 16px;margin: 0px;padding: 5px;padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 15px;">Prueba</a></li>
                <li> <a href="#" style="color: rgb(255,255,255);font-size: 19px;">Prestaciones</a></li>
                <li> <a href="#" style="color: rgb(255,255,255);font-size: 19px;">Servicios</a></li>
                <li class="sidebar-brand" style="margin-top: 100px;"> <a href="#" style="font-weight: bold;color: rgb(255,255,255);font-size: 22px;">Ir a Inventario</a><a href="#" style="font-weight: bold;color: rgb(255,255,255);font-size: 22px;margin-top: -25px;">Ir a Obra</a></li>
            </ul>
        </div>
        <div class="page-content-wrapper">
            <div class="container-fluid" style="background: #124177;"><a class="btn btn-link" role="button" id="menu-toggle" href="#menu-toggle"><i class="fa fa-bars" style="color: var(--white);"></i></a>
                <div class="row">
                    <div class="col-md-12">
                        <div>
                            <h1 style="color: rgb(255,255,255);">Modulo&nbsp;<small>Nomina</small></h1>
                        </div>
                    </div>
                </div>
            </div>
            <div>
             
                <!-- Aquí se inserta la tabla-->
                <div class="table-responsive" style="padding: 0px 20px 0px;">    
                <h1>Lista de pagos</h1>       
                <table id="tablaGenVia" class="table table-striped table-bordered table-condensed" style="width:100%;" >
                <button id="btnNuevoViatico" type="button" class="btn btn-info" data-toggle="modal"><i class="material-icons">library_add</i></button>    
                
                <thead class="text-center">
                        <tr>
                            <th>    </th>                            
                            <th>Nombre del trabajador</th>
                            <th>    </th>
                            <th>Fecha del viático</th>
                            <th>Monto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>                           
                    </tbody>        
                </table>               
            </div>
                <!-- Aquí se acaba la inserción de la tabla-->

        
            <!--Modal para crudGenerarVia-->

    
<div class="modal fade" role="dialog" tabindex="-1" id="modalViaticos">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header" style="text-align: center;">
                <h4 style="text-align: center;">Generar viático</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="viaticosForm" >
                    <div class="row">
                        <div class="col-md-6">
                            <div id="successfail"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-12 col-xl-12 offset-md-3 offset-lg-0 offset-xl-0" id="message">
                            <div class="form-group mb-3"><label class="form-label" for="from-phone">Nombre de trabajador</label>
                                <div class="input-group"><span class="input-group-text"><i class="fa fa-circle-o-notch"></i></span>
                                <select class="form-select" id="viaticosNombre" name="call time">
                                <?php
                                                //Incluimos el archivo de a conexión a la bd
                                                include_once 'bd/conexion.php';
                                                //Nos traemos el objeto de la conexión
                                                $objeto = new Conexion();
                                                $conexion = $objeto->Conectar();

                                                //Hacemos la consulta para traernos el campo que queramos
                                                $consulta = "SELECT IDTRABAJADOR, CONCAT(NOMBRETRAB,' ',APEPATTRAB,' ',APEMATTRAB) as 'NOMBRETRAB' FROM trabajadores";
                                                $resultado = $conexion->prepare($consulta);
                                                $resultado->execute();

                                                //Le pasamos los resultados al $data
                                                $data = $resultado->fetchAll();
                                                ?>
                                                <!--Aquí poblamos el select -->
                                                <?php foreach ($data as $row): ?>
                                                <!-- Le decimos que campo fue tomado desle la bd-->
                                                <option value="<?=$row["IDTRABAJADOR"]?>"><?=$row["NOMBRETRAB"]?></option>
                                                <?php endforeach ?>
                                                </select>
                                    </div>
                            </div>
                            <div class="form-group mb-3"><label class="form-label" for="from-name">Fecha de asignación</label>
                                <div class="input-group"><span class="input-group-text"><i class="material-icons">date_range</i></span>
                                <input class="form-control" id="fechaViaticos" name="name" placeholder type="date" /></div>
                            </div><button class="btn btn-primary d-block w-100" type="submit" style="width: 600px;">Enviar<i class="fa fa-chevron-circle-right"></i></button>
                            <hr class="d-flex d-md-none" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>   

<div role="dialog" tabindex="-1" class="modal fade show" id="modalAsignarViatico">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>Asignar viático</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="añadirViaticoForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div id="successfail"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-12 offset-md-0" id="message">
                            <hr class="d-flex d-md-none" />
                            <div class="form-group mb-3"><label class="form-label" for="from-phone">Tipo de viatico</label>
                                <div class="input-group"><span class="input-group-text"><i class="icon ion-fork"></i></span>
                                <select class="form-select" id="tipoViaticosNombre" name="call time">
                                <?php
                                                //Incluimos el archivo de a conexión a la bd
                                                include_once 'bd/conexion.php';
                                                //Nos traemos el objeto de la conexión
                                                $objeto = new Conexion();
                                                $conexion = $objeto->Conectar();

                                                //Hacemos la consulta para traernos el campo que queramos
                                                $consulta = "SELECT * FROM `tipoviaticos`";                                                
                                                $resultado = $conexion->prepare($consulta);
                                                $resultado->execute();

                                                //Le pasamos los resultados al $data
                                                $data = $resultado->fetchAll();
                                                ?>
                                                <!--Aquí poblamos el select -->
                                                <?php foreach ($data as $row): ?>
                                                <!-- Le decimos que campo fue tomado desle la bd-->
                                                <option value="<?=$row["IDTIVIATICO"]?>"><?=$row["NOMBRE"]?></option>
                                                <?php endforeach ?>
                                                </select>
                                    </div>
                            </div>
                            <div class="form-group mb-3"><label class="form-label" for="from-name">Monto</label>
                                <div class="input-group"><span class="input-group-text"><i class="fa fa-money"></i></span><input type="text" class="form-control" id="montoViatico" name="name" required placeholder /></div>
                            </div>
                            <div class="form-group mb-3"><label class="form-label" for="from-name">Descripción</label>
                                <div class="input-group"><span class="input-group-text"><i class="fa fa-keyboard-o"></i></span><input type="text" class="form-control" id="descripcionViatico" name="name" required placeholder /></div>
                            </div><button class="btn btn-primary d-block w-100" type="submit">Enviar<i class="fa fa-chevron-circle-right"></i></button>
                        </div>
                        <div class="col-12 col-md-6" id="message-1">
                            <hr class="d-flex d-md-none" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


           

            
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>
    <script src="assetsModal/bootstrap/js/bootstrap.min.js"></script>
    <script src="assetsModal/js/Contact-Form-v2-Modal--Full-with-Google-Map.js"></script>
    <!-- Cosas para al datatable -->
     <!-- jQuery, Popper.js, Bootstrap JS -->
     <script src="assets/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/popper/popper.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="assets/js/Contact-Form-v2-Modal--Full-with-Google-Map.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="assets/datatables/datatables.min.js"></script>    
    <script type="text/javascript" src="validaciones.js"></script>   
    <script type="text/javascript" src="main.js"></script>  


</body>
<footer style="margin: 0px 0px 0px;">
        <div class="row">
            <div class="col-sm-6 col-md-4 footer-navigation">
                <h3><a href="#">Company<span>logo </span></a></h3>
                <p class="links"><a href="#">Home</a><strong> · </strong><a href="#">Blog</a><strong> · </strong><a href="#">Pricing</a><strong> · </strong><a href="#">About</a><strong> · </strong><a href="#">Faq</a><strong> · </strong><a href="#">Contact</a></p>
                <p class="company-name">Company Name © 2015 </p>
            </div>
            <div class="col-sm-6 col-md-4 footer-contacts">
                <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                    <p><span class="new-line-span">21 Revolution Street</span> Paris, France</p>
                </div>
                <div><i class="fa fa-phone footer-contacts-icon"></i>
                    <p class="footer-center-info email text-left"> +1 555 123456</p>
                </div>
                <div><i class="fa fa-envelope footer-contacts-icon"></i>
                    <p> <a href="#" target="_blank">support@company.com</a></p>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-md-4 footer-about">
                <h4>About the company</h4>
                <p> Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet. </p>
                <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a></div>
            </div>
        </div>
    </footer>
</html>