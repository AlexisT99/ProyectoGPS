$(document).ready(function() {
var user_id, opcion;
opcion = 4;
    
tablaGenVia = $('#tablaGenVia').DataTable({  
    "ajax":{            
        "url": "bd/crudGenerarVia.php", 
        "method": 'POST', //usamos el metodo POST
        "data":{opcion:opcion}, //enviamos opcion 4 para que haga un SELECT
        "dataSrc":""
    },
    "columns":[
        {"data": "IDVIATICO"},
        {"data": "NOMBRETRAB"},
        {"data": "IDTRABAJADOR"},
        {"data": "FECHAASIG"},
        {"data": "MONTO"},
        {"defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btn-sm 'id='btnAgregarVia' ><i class='material-icons'>add_circle</i></button><button class='btn btn-info btn-sm' id='btnVerVia'><i class='material-icons'>info</i></button></div></div>"}
    ]
});     

//ocultar la ultima columna
var dt = $('#tablaGenVia').DataTable();
dt.column(2).visible(false);
dt.column(0).visible(false);

var fila; //captura la fila, para editar o eliminar
//submit para el Alta y Actualización
$('#viaticosForm').submit(function(e){                         
    e.preventDefault(); //evita el comportambiento normal del submit, es decir, recarga total de la página
    IDTRABAJADOR =$.trim($('#viaticosNombre option:selected').val());       
    FECHAASIG = $.trim($('#fechaViaticos').val());  
    $.ajax({
          url: "bd/crudGenerarVia.php",
          type: "POST",
          datatype:"json",    
          data:  {
            IDTRABAJADOR:IDTRABAJADOR,
            FECHAASIG:FECHAASIG,
            opcion:opcion},    
          success: function(data) {
            tablaGenVia.ajax.reload(null, false);
           }
           
        });			        
    $('#modalViaticos').modal('hide');											     			
});
        
 

//para limpiar los campos antes de dar de Alta una Persona
$("#btnNuevoViatico").click(function(){
    opcion = 1; //alta           
    id_viatico=null;
    $("#viaticosForm").trigger("reset");
    $(".modal-header").css( "background-color", "#17a2b8");
    $(".modal-header").css( "color", "white" );
    $(".modal-title").text("Alta de inventario");
    $('#modalViaticos').modal('show');	    
});

//Agregar viaticos a trabajadores      
$(document).on("click", "#btnAgregarVia", function(){
    
    var dt = $('#tablaGenVia').DataTable();
    dt.column(0).visible(true);                    
    opcion = 2;//editar

    fila = $(this).closest("tr");	        
    id_viatico = parseInt(fila.find('td:eq(0)').text()); //capturo el ID	  

    var dt = $('#tablaGenVia').DataTable();
    dt.column(2).visible(false);
    dt.column(0).visible(false);

    $(".modal-header").css("background-color", "#007bff");
    $(".modal-header").css("color", "white" );
    $(".modal-title").text("Editar inventariox");		
    $('#modalAsignarViatico').modal('show');		    


});

$('#añadirViaticoForm').submit(function(e){                         
    e.preventDefault(); //evita el comportambiento normal del submit, es decir, recarga total de la página
    IDTIVIATICO =$.trim($('#tipoViaticosNombre option:selected').val());       
    MONTOVIAT = $.trim($('#montoViatico').val());
    DESCVIAT = $.trim($('#descripcionViatico').val());
    $.ajax({
          url: "bd/crudGenerarVia.php",
          type: "POST",
          datatype:"json",    
          data:  {
            id_viatico:id_viatico,
            IDTIVIATICO:IDTIVIATICO,
            MONTOVIAT:MONTOVIAT,
            DESCVIAT:DESCVIAT,
            opcion:opcion},    
          success: function(data) {
            tablaGenVia.ajax.reload(null, false);
           }
           
        });			        
    $('#modalAsignarViatico').modal('hide');											     			
});


//Borrar
$(document).on("click", ".btnBorrar", function(){
    fila = $(this);           
    id_viatico = parseInt($(this).closest('tr').find('td:eq(0)').text()) ;		
    opcion = 3; //eliminar        
    var respuesta = confirm("¿Está seguro de borrar el registro "+id_viatico+"?");                
    if (respuesta) {            
        $.ajax({
          url: "bd/crudGenerarVia.php",
          type: "POST",
          datatype:"json",    
          data:  {opcion:opcion, id_viatico:id_viatico},    
          success: function() {
              tablaGenVia.row(fila.parents('tr')).remove().draw();                  
           }
        });	
    }
 });
     
});    