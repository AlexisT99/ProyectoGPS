<?php
    include("AgregarEquipo/index.php");
    include("Equipo.php");
    include("Mantenimiento.php");
    include("Material.php");
    include("Seguro.php");
    
?>