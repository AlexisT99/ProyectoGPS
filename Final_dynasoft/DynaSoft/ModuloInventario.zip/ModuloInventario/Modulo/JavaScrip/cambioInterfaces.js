function cambioEq_Ma() {

    location.href = "interfaz_ta_Materiales.html"

}

function cambioMa_Eq() {

    location.href = "interfaz_inv.html"

}