
class  moduloAgregar   {
        
    constructor (moe,mom) {
        this.me = moe;
        this.mm = mom;          
    }
  
};
